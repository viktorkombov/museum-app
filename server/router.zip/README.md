# rest-api-for-angular-project
This is an express.js server for a website made with Angular.
