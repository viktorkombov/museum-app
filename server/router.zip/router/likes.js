const express = require('express');
const postController = require('../controllers/postController');
const router = express.Router();
const { auth } = require('../utils');


module.exports = router
